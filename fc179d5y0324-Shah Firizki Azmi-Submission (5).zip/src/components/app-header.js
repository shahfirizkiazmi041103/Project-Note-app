class AppHeader extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <style>
        header {
          background-color: #343a40;
          color: white;
          padding: 1rem;
          text-align: center;
        }
        h1 {
          margin: 0;
        }
      </style>
      <header>
        <h1>Aplikasi Catatan</h1>
      </header>
    `;
  }
}

customElements.define('app-header', AppHeader);
