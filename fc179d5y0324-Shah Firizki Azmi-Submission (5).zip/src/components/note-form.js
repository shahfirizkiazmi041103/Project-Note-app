import { addNote } from '../scripts/api.js';

class NoteForm extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    this.render();
    this.setupForm();
  }

  showLoading() {
    const submitBtn = this.shadowRoot.querySelector('#submitBtn');
    submitBtn.disabled = true;
    submitBtn.innerHTML = `
      <span class="spinner"></span> Menyimpan...
    `;
  }

  showError(message) {
    const errorElement = document.createElement('div');
    errorElement.className = 'error-message';
    errorElement.textContent = message;
    errorElement.style.color = '#dc3545';
    errorElement.style.marginTop = '0.5rem';

    const form = this.shadowRoot.querySelector('form');
    const existingError = this.shadowRoot.querySelector('.error-message');
    if (existingError) {
      form.replaceChild(errorElement, existingError);
    } else {
      form.appendChild(errorElement);
    }
  }

  clearError() {
    const existingError = this.shadowRoot.querySelector('.error-message');
    if (existingError) {
      existingError.remove();
    }
  }

  setupForm() {
    const form = this.shadowRoot.querySelector('form');
    const titleInput = this.shadowRoot.querySelector('#title');
    const bodyInput = this.shadowRoot.querySelector('#body');
    const submitBtn = this.shadowRoot.querySelector('#submitBtn');

    // Validasi real-time
    const validateForm = () => {
      submitBtn.disabled = !(titleInput.value.trim() && bodyInput.value.trim());
    };

    titleInput.addEventListener('input', validateForm);
    bodyInput.addEventListener('input', validateForm);

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      this.clearError();

      try {
        this.showLoading();
        await addNote({
          title: titleInput.value.trim(),
          body: bodyInput.value.trim(),
        });

        this.dispatchEvent(new CustomEvent('note-added', { bubbles: true }));
        form.reset();
        validateForm();
      } catch (error) {
        this.showError(error.message);
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Tambah Catatan';
      }
    });
  }

  render() {
    this.shadowRoot.innerHTML = `
      <style>
        form {
          max-width: 500px;
          margin: 0 auto;
          padding: 1rem;
          background: white;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .form-group {
          margin-bottom: 1rem;
        }
        label {
          display: block;
          margin-bottom: 0.5rem;
          font-weight: 500;
        }
        input, textarea {
          width: 96%;
          padding: 0.5rem;
          border: 1px solid #ced4da;
          border-radius: 4px;
          font-size: 1rem;
        }
        textarea {
          min-height: 100px;
          resize: vertical;
        }
        button {
          width: 100%;
          padding: 0.75rem;
          background-color: #28a745;
          color: white;
          border: none;
          border-radius: 4px;
          font-size: 1rem;
          font-weight: 500;
          cursor: pointer;
          transition: background-color 0.2s;
        }
        button:hover {
          background-color: #218838;
        }
        button:disabled {
          background-color: #6c757d;
          cursor: not-allowed;
        }
        .spinner {
          display: inline-block;
          width: 1rem;
          height: 1rem;
          border: 2px solid rgba(255,255,255,0.3);
          border-radius: 50%;
          border-top-color: white;
          animation: spin 1s linear infinite;
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      </style>
      <form>
        <div class="form-group">
          <label for="title">Judul</label>
          <input type="text" id="title" placeholder="Masukkan judul catatan" required>
        </div>
        <div class="form-group">
          <label for="body">Isi Catatan</label>
          <textarea id="body" placeholder="Tulis isi catatan Anda di sini" required></textarea>
        </div>
        <button type="submit" id="submitBtn" disabled>Tambah Catatan</button>
      </form>
    `;
  }
}

customElements.define('note-form', NoteForm);
