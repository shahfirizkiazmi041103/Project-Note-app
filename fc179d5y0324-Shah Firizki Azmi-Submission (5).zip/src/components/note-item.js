import { deleteNote, archiveNote, unarchiveNote } from '../scripts/api.js';

class NoteItem extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.isProcessing = false; // Tambahkan state untuk menandai sedang proses
  }

  connectedCallback() {
    this.render();
  }

  static get observedAttributes() {
    return ['id', 'title', 'body', 'createdAt', 'archived'];
  }

  attributeChangedCallback(name, oldValue, newValue) {
    if (oldValue !== newValue && this.isConnected) {
      this.render();
    }
  }

  async handleDelete() {
    if (this.isProcessing) return;
    
    try {
      if (!confirm('Apakah Anda yakin ingin menghapus catatan ini?')) return;

      this.isProcessing = true;
      this.showLoading();
      
      await deleteNote(this.getAttribute('id'));
      
      this.dispatchEvent(
        new CustomEvent('note-deleted', {
          bubbles: true,
          composed: true, // Tambahkan composed agar event bisa melewati shadow DOM
          detail: { id: this.getAttribute('id') },
        })
      );
    } catch (error) {
      this.showError(error.message);
    } finally {
      this.isProcessing = false;
    }
  }

  async handleArchive() {
    if (this.isProcessing) return;
    
    try {
      const isArchived = this.getAttribute('archived') === 'true';
      this.isProcessing = true;
      this.showLoading();

      if (isArchived) {
        await unarchiveNote(this.getAttribute('id'));
      } else {
        await archiveNote(this.getAttribute('id'));
      }

      this.dispatchEvent(
        new CustomEvent('note-updated', {
          bubbles: true,
          composed: true,
          detail: {
            id: this.getAttribute('id'),
            archived: !isArchived,
          },
        })
      );
      
      // Update attribute untuk render ulang
      this.setAttribute('archived', String(!isArchived));
    } catch (error) {
      this.showError(error.message);
    } finally {
      this.isProcessing = false;
    }
  }

  showLoading() {
    const cardContent = this.shadowRoot.querySelector('.note-card');
    if (!cardContent) return;

    const loadingElement = document.createElement('div');
    loadingElement.innerHTML = `
      <style>
        .loading-overlay {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(255, 255, 255, 0.8);
          display: flex;
          justify-content: center;
          align-items: center;
          z-index: 10;
          border-radius: 8px;
        }
        .loading-spinner {
          border: 3px solid rgba(0,0,0,0.1);
          border-radius: 50%;
          border-top: 3px solid #3498db;
          width: 20px;
          height: 20px;
          animation: spin 1s linear infinite;
        }
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      </style>
      <div class="loading-overlay">
        <div class="loading-spinner"></div>
      </div>
    `;

    cardContent.style.position = 'relative';
    cardContent.appendChild(loadingElement.firstChild);
  }

  clearLoading() {
    const loadingOverlay = this.shadowRoot.querySelector('.loading-overlay');
    if (loadingOverlay) {
      loadingOverlay.remove();
    }
  }

  showError(message) {
    const errorElement = document.createElement('div');
    errorElement.innerHTML = `
      <style>
        .error-message {
          color: #dc3545;
          font-size: 0.9rem;
          margin-top: 0.5rem;
          text-align: center;
        }
        .retry-btn {
          margin-top: 0.5rem;
          padding: 0.25rem 0.5rem;
          background-color: #dc3545;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size: 0.8rem;
        }
      </style>
      <div class="error-message">
        <p>${message}</p>
        <button class="retry-btn">Coba Lagi</button>
      </div>
    `;

    const actionsContainer = this.shadowRoot.querySelector('.note-actions');
    if (actionsContainer) {
      const existingError = this.shadowRoot.querySelector('.error-message');
      if (existingError) existingError.remove();
      
      actionsContainer.appendChild(errorElement.firstChild);
      
      this.shadowRoot
        .querySelector('.retry-btn')
        .addEventListener('click', () => {
          errorElement.remove();
          this.render();
        });
    }
  }

  render() {
    const title = this.getAttribute('title');
    const body = this.getAttribute('body');
    const createdAt = this.getAttribute('createdAt');
    const isArchived = this.getAttribute('archived') === 'true';

    this.shadowRoot.innerHTML = `
      <style>
        .note-card {
          background: white;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
          padding: 1rem;
          margin-bottom: 1rem;
          transition: all 0.3s ease;
          border-left: 4px solid ${isArchived ? '#6c757d' : '#28a745'};
        }
        .note-card:hover {
          transform: translateY(-3px);
          box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }
        .note-title {
          margin: 0 0 0.5rem 0;
          color: #343a40;
          font-size: 1.2rem;
        }
        .note-body {
          margin: 0 0 0.5rem 0;
          color: #6c757d;
          line-height: 1.5;
        }
        .note-date {
          font-size: 0.8rem;
          color: #6c757d;
          margin-bottom: 1rem;
          display: block;
        }
        .note-actions {
          display: flex;
          gap: 0.5rem;
        }
        .btn {
          padding: 0.5rem 1rem;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-weight: 500;
          transition: all 0.2s;
          flex: 1;
        }
        .btn:hover {
          opacity: 0.9;
        }
        .btn:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }
        .btn-delete {
          background-color: #dc3545;
          color: white;
        }
        .btn-archive {
          background-color: ${isArchived ? '#17a2b8' : '#ffc107'};
          color: ${isArchived ? 'white' : '#343a40'};
        }
        .archive-badge {
          display: inline-block;
          background-color: #6c757d;
          color: white;
          padding: 0.2rem 0.5rem;
          border-radius: 4px;
          font-size: 0.7rem;
          margin-left: 0.5rem;
        }
      </style>
      <div class="note-card">
        <h3 class="note-title">${title} ${isArchived ? '<span class="archive-badge">Terarsip</span>' : ''}</h3>
        <p class="note-body">${body}</p>
        <small class="note-date">${new Date(createdAt).toLocaleString()}</small>
        <div class="note-actions">
          <button class="btn btn-archive" ${this.isProcessing ? 'disabled' : ''}>
            ${isArchived ? 'Batalkan Arsip' : 'Arsipkan'}
          </button>
          <button class="btn btn-delete" ${this.isProcessing ? 'disabled' : ''}>Hapus</button>
        </div>
      </div>
    `;

    this.shadowRoot
      .querySelector('.btn-delete')
      .addEventListener('click', () => this.handleDelete());
    this.shadowRoot
      .querySelector('.btn-archive')
      .addEventListener('click', () => this.handleArchive());
  }
}

// Cek apakah element sudah terdaftar sebelum mendefinisikan
if (!customElements.get('note-item')) {
  customElements.define('note-item', NoteItem);
}