import { getActiveNotes, getArchivedNotes } from '../scripts/api.js';

class NoteList extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.notes = [];
    this.isArchivedView = false;
    this.listenersAttached = false;
    this.isLoading = false; // Tambahkan state untuk loading
  }

  async connectedCallback() {
    await this.loadNotes();
    this.setupEventListeners();
  }

  async loadNotes() {
    if (this.isLoading) return; // Hindari multiple requests
    
    this.isLoading = true;
    this.renderLoading();
    
    try {
      this.notes = this.isArchivedView
        ? await getArchivedNotes()
        : await getActiveNotes();
      this.render();
    } catch (error) {
      console.error('Gagal memuat catatan:', error);
      this.showError(error.message);
    } finally {
      this.isLoading = false; // Pastikan loading dihentikan
    }
  }

  toggleView() {
    this.isArchivedView = !this.isArchivedView;
    this.loadNotes();
  }

  renderLoading() {
    this.shadowRoot.innerHTML = `
      <style>
        .loading-container {
          text-align: center;
          padding: 2rem;
        }
        .spinner {
          display: inline-block;
          width: 2rem;
          height: 2rem;
          border: 3px solid rgba(0,0,0,0.1);
          border-radius: 50%;
          border-top-color: #3498db;
          animation: spin 1s linear infinite;
        }
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      </style>
      <div class="loading-container">
        <div class="spinner"></div>
        <p>Memuat catatan...</p>
      </div>
    `;
  }

  showError(message) {
    this.shadowRoot.innerHTML = `
      <style>
        .error-container {
          text-align: center;
          padding: 2rem;
          color: #dc3545;
        }
        .retry-btn {
          margin-top: 1rem;
          padding: 0.5rem 1rem;
          background-color: #dc3545;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
        }
      </style>
      <div class="error-container">
        <p>${message}</p>
        <button class="retry-btn">Coba Lagi</button>
      </div>
    `;

    this.shadowRoot
      .querySelector('.retry-btn')
      .addEventListener('click', () => this.loadNotes());
  }

  setupEventListeners() {
    if (this.listenersAttached) return;

    // Gunakan arrow function untuk mempertahankan konteks this
    const handleNoteDeleted = () => this.loadNotes();
    const handleNoteUpdated = (e) => {
      const updatedNote = e.detail;
      if ((!this.isArchivedView && updatedNote.archived) || 
          (this.isArchivedView && !updatedNote.archived)) {
        this.loadNotes();
      }
    };
    const handleNoteAdded = () => this.loadNotes();

    this.addEventListener('note-deleted', handleNoteDeleted);
    this.addEventListener('note-updated', handleNoteUpdated);
    this.addEventListener('note-added', handleNoteAdded);

    // Delegasi event untuk toggle view
    this.shadowRoot.addEventListener('click', (e) => {
      if (e.target.classList.contains('toggle-view-btn')) {
        this.toggleView();
      }
    });

    this.listenersAttached = true;

    // Bersihkan event listeners jika komponen dilepas
    this._cleanup = () => {
      this.removeEventListener('note-deleted', handleNoteDeleted);
      this.removeEventListener('note-updated', handleNoteUpdated);
      this.removeEventListener('note-added', handleNoteAdded);
      this.listenersAttached = false;
    };
  }

  disconnectedCallback() {
    if (this._cleanup) {
      this._cleanup();
    }
  }

  render() {
    this.shadowRoot.innerHTML = `
      <style>
        .notes-container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 1rem;
        }
        .header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1rem;
        }
        .title {
          margin: 0;
          color: #343a40;
        }
        .toggle-view-btn {
          padding: 0.5rem 1rem;
          background-color: ${this.isArchivedView ? '#17a2b8' : '#6c757d'};
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
        }
        .notes-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
          gap: 1rem;
        }
        .empty-message {
          text-align: center;
          color: #6c757d;
          padding: 2rem;
          grid-column: 1 / -1;
        }
      </style>
      <div class="notes-container">
        <div class="header">
          <h2 class="title">${this.isArchivedView ? 'Catatan Terarsip' : 'Catatan Aktif'}</h2>
          <button class="toggle-view-btn">
            ${this.isArchivedView ? 'Lihat Catatan Aktif' : 'Lihat Catatan Terarsip'}
          </button>
        </div>
        <div class="notes-grid">
          ${
            this.notes.length > 0
              ? this.notes
                  .map(
                    (note) => `  
                <note-item
                  id="${note.id}"
                  title="${note.title}"
                  body="${note.body}"
                  createdAt="${note.createdAt}"
                  archived="${note.archived}"
                ></note-item>
              `
                  )
                  .join('')
              : `<p class="empty-message">Tidak ada ${this.isArchivedView ? 'catatan terarsip' : 'catatan aktif'}</p>`
          }
        </div>
      </div>
    `;
  }
}

// Cek apakah element sudah terdaftar sebelum mendefinisikan
if (!customElements.get('note-list')) {
  customElements.define('note-list', NoteList);
}