// Import komponen
import './components/app-header.js';
import './components/note-form.js';
import './components/note-list.js';
import './components/note-item.js';



// Custom Element untuk Header
class AppHeader extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `
      <style>
        header {
          background-color: #343a40;
          color: white;
          padding: 1rem;
          text-align: center;
        }
        h1 {
          margin: 0;
        }
      </style>
      <header>
        <h1>Aplikasi Catatan</h1>
      </header>
    `;
  }
}



// Inisialisasi aplikasi
document.addEventListener('DOMContentLoaded', () => {
  console.log('Aplikasi Catatan siap digunakan!');
    const noteList = document.querySelector('note-list');
    document.querySelector('note-form').addEventListener('note-added', () => {
    noteList.loadNotes(); // Memuat ulang catatan setelah event 'note-added'
  });
});
