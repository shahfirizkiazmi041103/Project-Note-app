const BASE_URL = 'https://notes-api.dicoding.dev/v2';

// Kriteria Wajib: h API untuk mendapatkan catatan
export const getActiveNotes = async () => {
  try {
    const response = await fetch(`${BASE_URL}/notes`);
    const data = await response.json();
    if (!response.ok)
      throw new Error(data.message || 'Gagal mengambil catatan aktif');
    return data.data;
  } catch (error) {
    throw new Error(`Error: ${error.message}`);
  }
};

// Kriteria Wajib: Menambahkan catatan baru
export const addNote = async ({ title, body }) => {
  try {
    const response = await fetch(`${BASE_URL}/notes`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ title, body }),
    });
    const data = await response.json();
    if (!response.ok)
      throw new Error(data.message || 'Gagal menambahkan catatan');
    return data.data;
  } catch (error) {
    throw new Error(`Error: ${error.message}`);
  }
};

// Kriteria Wajib: Menghapus catatan
export const deleteNote = async (id) => {
  try {
    const response = await fetch(`${BASE_URL}/notes/${id}`, {
      method: 'DELETE',
    });
    const data = await response.json();
    if (!response.ok)
      throw new Error(data.message || 'Gagal menghapus catatan');
    return data.data;
  } catch (error) {
    throw new Error(`Error: ${error.message}`);
  }
};

// Kriteria Opsional: Mendapatkan catatan terarsip
export const getArchivedNotes = async () => {
  try {
    const response = await fetch(`${BASE_URL}/notes/archived`);
    const data = await response.json();
    if (!response.ok)
      throw new Error(data.message || 'Gagal mengambil catatan terarsip');
    return data.data;
  } catch (error) {
    throw new Error(`Error: ${error.message}`);
  }
};

// Kriteria Opsional: Mengarsipkan catatan
export const archiveNote = async (id) => {
  try {
    const response = await fetch(`${BASE_URL}/notes/${id}/archive`, {
      method: 'POST',
    });
    const data = await response.json();
    if (!response.ok)
      throw new Error(data.message || 'Gagal mengarsipkan catatan');
    return data.data;
  } catch (error) {
    throw new Error(`Error: ${error.message}`);
  }
};

// Kriteria Opsional: Membatalkan arsip
export const unarchiveNote = async (id) => {
  try {
    const response = await fetch(`${BASE_URL}/notes/${id}/unarchive`, {
      method: 'POST',
    });
    const data = await response.json();
    if (!response.ok)
      throw new Error(data.message || 'Gagal membatalkan arsip');
    return data.data;
  } catch (error) {
    throw new Error(`Error: ${error.message}`);
  }
};
