// Custom Element untuk Header
class AppHeader extends HTMLElement {
  constructor() {
    super();
    this.innerHTML = `<h1>My Notes</h1>`;
  }
}
customElements.define('app-header', AppHeader);

// Custom Element untuk Kontainer Utama
class NoteContainer extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });

    const container = document.createElement('section');
    container.classList.add('note-container');

    const noteList = document.createElement('note-list'); // Custom Element NoteList
    container.appendChild(noteList);

    const style = document.createElement('style');
    style.textContent = `
            .note-container {
                max-width: 1000px;
                margin: 20px auto;
                padding: 20px;
                background: #f9f9f9;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
        `;

    this.shadowRoot.appendChild(style);
    this.shadowRoot.appendChild(container);
  }
}
customElements.define('note-container', NoteContainer);

// Custom Element untuk Note Item
class NoteItem extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });

    const wrapper = document.createElement('div');
    wrapper.classList.add('note-item');

    const title = document.createElement('h3');
    const body = document.createElement('p');
    const date = document.createElement('small');

    title.textContent = this.getAttribute('title');
    body.textContent = this.getAttribute('body');
    date.textContent = `Created: ${new Date(this.getAttribute('createdAt')).toLocaleDateString()}`;

    wrapper.appendChild(title);
    wrapper.appendChild(body);
    wrapper.appendChild(date);

    const style = document.createElement('style');
    style.textContent = `
            .note-item {
                background-color: white;
                border: 1px solid #ddd;
                border-radius: 8px;
                padding: 16px;
                box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
                text-align: left;
            }
            .note-item h3 {
                margin-top: 0;
                font-size: 18px;
            }
            .note-item p {
                font-size: 14px;
                color: #555;
            }
            .note-item small {
                display: block;
                margin-top: 10px;
                font-size: 12px;
                color: gray;
            }
        `;

    this.shadowRoot.appendChild(style);
    this.shadowRoot.appendChild(wrapper);
  }
}
customElements.define('note-item', NoteItem);

// Custom Element untuk Daftar Note
class NoteList extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });

    const container = document.createElement('div');
    container.classList.add('notes-container');

    notesData.forEach((note) => {
      const noteElement = document.createElement('note-item');
      noteElement.setAttribute('title', note.title);
      noteElement.setAttribute('body', note.body);
      noteElement.setAttribute('createdAt', note.createdAt);
      container.appendChild(noteElement);
    });

    const style = document.createElement('style');
    style.textContent = `
            .notes-container {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 16px;
                padding: 20px;
            }
        `;

    this.shadowRoot.appendChild(style);
    this.shadowRoot.appendChild(container);
  }
}
customElements.define('note-list', NoteList);
